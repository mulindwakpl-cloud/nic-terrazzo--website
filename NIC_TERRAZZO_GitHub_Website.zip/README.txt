NIC TERRAZZO WEBSITE — BEGINNER SETUP

FILES
- index.html: the website homepage

PUBLISH WITH GITHUB PAGES
1. Sign in at https://github.com/
2. Create a new repository named nic-terrazzo-website.
3. Open the repository and choose Add file > Upload files.
4. Upload index.html and commit the changes.
5. Open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait a few minutes. GitHub will show your published website address in the Pages section.

IMPORTANT
- The site is a starter template and is not published online until you upload it and enable Pages.
- Gallery tiles are placeholders. Replace them with your own photos before advertising the site.
- The page uses an online background image, so that image needs an internet connection.
- The WhatsApp button uses the phone number supplied for NIC TERRAZZO (0700447921).
- Check all details and links before sharing the website with customers.
